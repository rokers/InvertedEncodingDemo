# InvertedEncodingDemo
 
Demonstration of the decoding of visual stimuli based on neural data by way of an inverted encoding model. 
